<div class="custom-cursor__cursor"></div>
<div class="custom-cursor__cursor-two"></div>