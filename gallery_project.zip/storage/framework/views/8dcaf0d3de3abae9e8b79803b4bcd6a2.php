<div class="project-details__pagination-box">
    <ul class="project-details__pagination justify-content-center list-unstyled clearfix">
        <li>
            <ul class="counts">
                
                <?php if($galleryItems->onFirstPage()): ?>
                    <li class="count disabled"><a href="#"><i class="icon-left-arrow"></i></a></li>
                <?php else: ?>
                    <li class="count"><a href="<?php echo e($galleryItems->previousPageUrl()); ?>"><i class="icon-left-arrow"></i></a></li>
                <?php endif; ?>

                
                <?php
                    $currentPage = $galleryItems->currentPage();
                    $lastPage = $galleryItems->lastPage();
                    $range = 3; // Show 3 pages before and after the current page
                    $start = max($currentPage - $range, 1); // Start of range
                    $end = min($currentPage + $range, $lastPage); // End of range

                    // Ensure the range doesn't go out of bounds (1-3 pages before and after current)
                    if ($currentPage < 4) {
                        $end = min($lastPage, 7); // For the first pages
                    } elseif ($currentPage > $lastPage - 3) {
                        $start = max(1, $lastPage - 6); // For the last pages
                    }
                ?>

                
                <?php for($page = $start; $page <= $end; $page++): ?>
                    <li class="count <?php if($page == $currentPage): ?> active <?php endif; ?>">
                        <a href="<?php echo e($galleryItems->url($page)); ?>">
                            <span><?php echo e($page); ?></span>
                        </a>
                    </li>
                <?php endfor; ?>

                
                <?php if($end < $lastPage): ?>
                    <li class="count">...</li>
                <?php endif; ?>

                
                <?php if($galleryItems->hasMorePages()): ?>
                    <li class="count"><a href="<?php echo e($galleryItems->nextPageUrl()); ?>"><i class="icon-right-arrow"></i></a></li>
                <?php else: ?>
                    <li class="count disabled"><a href="#"><i class="icon-right-arrow"></i></a></li>
                <?php endif; ?>
            </ul>
        </li>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/vendor/pagination/custom-pagination.blade.php ENDPATH**/ ?>