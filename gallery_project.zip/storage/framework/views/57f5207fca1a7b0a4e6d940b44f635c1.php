

<?php $__env->startSection('title', $image->image_name . ' - Gallery App'); ?>
<?php $__env->startSection('description', $image->description); ?>
<?php $__env->startSection('keywords', $image->tags); ?>

<?php $__env->startSection('content'); ?>
<?php
    $Title='Home';
    $Title2 = 'Category';
    $SubTitle = "Image Details";

?>
<?php echo $__env->make('partials.Page_Header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="team-details">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="team-details__left">
                        <div class="team-details__img">
                            <img src="<?php echo e($image->database->base_url); ?>upload/<?php echo e($image->image); ?>" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="team-details__right">
                        <h3 class="team-details__name text-white"><?php echo e($image->image_name); ?></h3>
                        <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="team-details__sub-title text-white text-decoration-underline"><?php echo e($category->category_name); ?></a>
                        <p class="team-details__text-1 text-white"><?php echo e($image->description); ?></p>
                        <div class="border-bottom mb-3"></div>
                        <ul class="ps-0 list-unstyled mb-3">
                            <li>
                                <div class="d-flex items-center gap-2 text-white">
                                    <strong>Size: </strong> <p><?php echo e($image->image_size); ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex items-center gap-2 text-white">
                                    <strong>Resolution: </strong> <p><?php echo e($image->image_resolution); ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="d-flex items-center gap-2 text-white">
                                    <strong>Extension: </strong> <p><?php echo e($image->image_extension); ?></p>
                                </div>
                            </li>
                        </ul>
                        <a href="<?php echo e(route('image.download', $image->slug)); ?>" class="thm-btn login-page__form-btn">Download <i class="fa fa-download ms-2"></i></a>
                        <div class="blog-details__bottom">
                            <p class="blog-details__tags gap-1 d-flex flex-wrap">
                                <span class="text-white">Tags</span>
                                <?php $__currentLoopData = explode(",",$image->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('search', ['q' => trim($tag)])); ?>" class="mx-0"><?php echo e($tag); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/image/show.blade.php ENDPATH**/ ?>