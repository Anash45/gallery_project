<div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6">
    <a href="<?php echo e($ad->link); ?>" class="ad_single">
        <div class="ad_img-box">
            <div class="ad_icon-box">
                <img src="<?php echo e(asset("/assets/images/ad.png")); ?>" class="ad_icon" />
            </div>
            <div class="ad_img">
                <img src="<?php echo e($ad->image_path); ?>" loading="lazy" alt="<?php echo e($ad->title); ?>" class="w-100">
            </div>
            <div class="ad_content">
                <h5 class="ad_title text-white"><span><?php echo e($ad->title); ?></span></h5>
                <p class="ad_description"><?php echo e($ad->description); ?></p>
            </div>
        </div>
    </a>
</div><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/ad_card.blade.php ENDPATH**/ ?>