<div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div>
</div><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/stricky-header.blade.php ENDPATH**/ ?>