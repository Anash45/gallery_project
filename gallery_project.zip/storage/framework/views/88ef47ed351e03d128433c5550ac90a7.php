

<?php $__env->startSection('title', 'Blog - Gallery App'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $Title = 'Home';
    $Title2 = 'Blog';
    $SubTitle = "Blog";
?>

<?php echo $__env->make('partials.Page_Header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="blog-sidebar">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-7">
                <div class="blog-sidebar__left">
                    <div class="blog-sidebar__content-box">
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- ..::Blog sidebar Single Start ::.. -->
                            <div class="blog-sidebar__single">
                                <div class="blog-sidebar__img">
                                    <?php if(isset($blog['_embedded']['wp:featuredmedia'][0]['source_url'])): ?>
                                        <img src="<?php echo e($blog['_embedded']['wp:featuredmedia'][0]['source_url']); ?>" alt="<?php echo e($blog['title']['rendered']); ?>">
                                    <?php else: ?>
                                        <img src="default-image.jpg" alt="No Image Available">
                                    <?php endif; ?>
                                    <div class="blog-sidebar__date-box">
                                        <span><?php echo e(date('d', strtotime($blog['date']))); ?></span>
                                        <p><?php echo e(date('F Y', strtotime($blog['date']))); ?></p>
                                    </div>
                                </div>
                                <div class="blog-sidebar__content">
                                    <ul class="blog-sidebar__meta list-unstyled">
                                        <li>
                                            <?php if(isset($blog['_embedded']['author'][0]['name'])): ?>
                                                <a href="#"><i class="fas fa-user-circle"></i>by <?php echo e($blog['_embedded']['author'][0]['name']); ?></a>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                    <h3 class="blog-sidebar__title">
                                        <a href="/blog/<?php echo e($blog['slug']); ?>"><?php echo e($blog['title']['rendered']); ?></a>
                                    </h3>
                                    <p class="blog-sidebar__text">
                                        <?php echo Str::limit(strip_tags($blog['excerpt']['rendered']), 150); ?>

                                    </p>
                                    <div class="blog-sidebar__btn">
                                        <a href="/blog/<?php echo e($blog['slug']); ?>">More <span class="fa fa-play"></span></a>
                                    </div>
                                </div>
                            </div>
                            <!-- ..::Blog sidebar Single End ::.. -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- Pagination -->

                    <!-- Pagination -->
                    <div class="project-details__pagination-box">
                        <ul class="project-details__pagination justify-content-center list-unstyled clearfix">
                            <li>
                                <ul class="counts">
                                    <!-- Previous Button -->
                                    <li class="count <?php echo e($currentPage == 1 ? 'disabled' : ''); ?>">
                                        <a href="/blog/?page=<?php echo e(max($currentPage - 1, 1)); ?>"><i class="icon-left-arrow"></i></a>
                                    </li>

                                    <!-- Page Number Links -->
                                    <?php for($i = 1; $i <= $totalPages[0]; $i++): ?>
                                        <li class="count <?php echo e($currentPage == $i ? 'active' : ''); ?>">
                                            <a href="/blog/?page=<?php echo e($i); ?>">
                                                <span><?php echo e($i); ?></span>
                                            </a>
                                        </li>
                                    <?php endfor; ?>

                                    <!-- Next Button -->
                                    <li class="count <?php echo e($currentPage == $totalPages ? 'disabled' : ''); ?>">
                                        <a href="/blog/?page=<?php echo e(min($currentPage + 1, $totalPages)); ?>"><i class="icon-right-arrow"></i></a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                    
                </div>
            </div>

            <div class="col-xl-4 col-lg-5">
                
                <?php echo $__env->make('partials.blog-sidebar', [
                    'categories' => $categories,
                    'tags' => $tags,
                    'latestPosts' => $latestPosts,
                    'search' => request()->get('search')
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/blog/index.blade.php ENDPATH**/ ?>