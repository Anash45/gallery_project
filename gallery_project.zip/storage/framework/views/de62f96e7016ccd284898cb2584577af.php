<div class="sidebar">
    <!-- Search Section -->
    <div class="sidebar__single sidebar__search">
        <form action="<?php echo e(route('blog.index')); ?>" method="GET" class="sidebar__search-form">
            <input type="search" name="search" placeholder="Keyword..." value="<?php echo e(request()->get('search')); ?>">
            <button type="submit"><i class="icon-magnifying-glass"></i></button>
        </form>
    </div>

    <!-- Latest Posts Section -->
    <div class="sidebar__single sidebar__post">
        <h3 class="sidebar__title">Latest posts</h3>
        <ul class="sidebar__post-list list-unstyled">
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="sidebar__post-image">
                        <img src="<?php echo e($post['_embedded']['wp:featuredmedia'][0]['source_url']); ?>" alt="">
                    </div>
                    <div class="sidebar__post-content">
                        <h3>
                            <span class="sidebar__post-content-meta"><i class="fa fa-clock"></i><?php echo e(\Carbon\Carbon::parse($post['date'])->format('d M, Y')); ?></span>
                            <a href="/blog/<?php echo e($post['slug']); ?>"><?php echo e($post['title']['rendered']); ?></a>
                        </h3>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <!-- Categories Section -->
    <div class="sidebar__single sidebar__category">
        <h3 class="sidebar__title">Categories</h3>
        <ul class="sidebar__category-list list-unstyled">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('blog.index', ['category' => $category['id']])); ?>"><?php echo $category['name']; ?><span class="fas fa-caret-right"></span></a></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <!-- Tags Section -->
    <div class="sidebar__single sidebar__tags">
        <h3 class="sidebar__title">Tags</h3>
        <div class="sidebar__tags-list">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog.index', ['tag' => $tag['id']])); ?>"><?php echo e($tag['name']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/blog-sidebar.blade.php ENDPATH**/ ?>