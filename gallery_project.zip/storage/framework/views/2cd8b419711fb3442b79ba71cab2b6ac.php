<footer class="site-footer">
    <div class="site-footer__bg" style="background-image: url(<?php echo asset('assets/images/backgrounds/site-footer-bg.png'); ?>);">
    </div>
    <div class="site-footer__bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="site-footer__bottom-inner">
                        <p class="site-footer__bottom-text">© Copyright 2025 by <a href="#">Company.com</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/footer.blade.php ENDPATH**/ ?>