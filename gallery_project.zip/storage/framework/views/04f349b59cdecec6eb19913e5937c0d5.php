<?php
    $categories = \App\Models\Category::where('category_status', 1)
        ->orderBy('category_name')
        ->get();
?> 
<header class="main-header">
    <nav class="main-menu">
        <div class="main-menu__wrapper">
            <div class="main-menu__wrapper-inner">
                <div class="main-menu__left flex-grow-1">
                    <div class="main-menu__logo">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/images/resources/logo-1.png')); ?>" alt=""></a>
                    </div>
                    <div class="main-menu__main-menu-box mx-auto">
                        <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                        <ul class="main-menu__list">
                            <li class="<?php echo e(request()->is('/') ? 'current' : ''); ?>">
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li class="dropdown <?php echo e(request()->is('category*') ? 'current' : ''); ?>">
                                <a href="#">Categories</a>
                                <ul class="sub-menu">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(url('/category/' . $category->slug)); ?>">
                                                <?php echo e($category->category_name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <li class="<?php echo e(request()->is('/blog/') ? 'current' : ''); ?>">
                                <a href="<?php echo e(route('blog.index')); ?>">Blog</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="main-menu__right">
                    <div class="main-menu__search-cart-box">
                        <div class="main-menu__search-box">
                            <a href="#" class="main-menu__search search-toggler icon-magnifying-glass"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/header.blade.php ENDPATH**/ ?>