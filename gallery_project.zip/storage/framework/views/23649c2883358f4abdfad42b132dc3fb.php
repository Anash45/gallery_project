<!DOCTYPE html>
<html lang="en">
     <?php $title = 'Home One' ?>  <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pitoon-dark.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>" />

    <body class="custom-cursor">
         <?php echo $__env->make('partials.cursor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
        <?php echo $__env->make('partials.preloader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- ..:: /.preloader  ::.. -->
        <div class="page-wrapper">
             <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- ..:: /.stricky-header  ::.. -->
            <main class="pt-5">
                <section class="project-one">
                    <div class="container">
                        <div class="section-title text-center">
                            <h2 class="section-title__title">Recent Uploads</h2>
                        </div>
                    </div>
                </section>
            </main>
            <!-- ..::Site Footer Start ::.. --> <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- ..::Site Footer End ::.. -->
        </div><!-- ..:: /.page-wrapper  ::.. -->
         <?php echo $__env->make('partials.mobile-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- ..:: /.mobile-nav__wrapper  ::.. -->
         <?php echo $__env->make('partials.search-popup', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- ..:: /.search-popup  ::.. -->
        <a href="#" data-target="html" class="scroll-to-target scroll-to-top">
            <i class="icon-up-arrow"></i>
        </a>
         <?php echo $__env->make('partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <script src="<?php echo e(asset('assets/js/pitoon.js')); ?>"></script>
    </body>

</html><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/index.blade.php ENDPATH**/ ?>