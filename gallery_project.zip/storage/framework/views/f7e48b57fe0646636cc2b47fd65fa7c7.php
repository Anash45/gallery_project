

<?php $__env->startSection('title', $category->category_name . ' - Gallery App'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $Title = 'Home';
    $Title2 = 'Category';
    $SubTitle = $category->category_name;
?>
<?php echo $__env->make('partials.Page_Header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="projects-page">
    <div class="container">
        <!-- Page Information (current page and item range) -->
        <?php if($galleryItems->count()): ?>
        
        <div class="row mb-4">
            <div class="col-12 text-center">
                <?php
                    $from = $galleryItems->firstItem();
                    $to = $galleryItems->lastItem();
                    $total = $galleryItems->total();
                    $currentPage = $galleryItems->currentPage();
                    $lastPage = $galleryItems->lastPage();
                ?>

                <p class="text-end">Showing <?php echo e($from); ?> to <?php echo e($to); ?> of <?php echo e($total); ?> images on page <?php echo e($currentPage); ?> of <?php echo e($lastPage); ?></p>
            </div>
        </div>

        <!-- Gallery Items -->
        <div class="row">
            <?php
                $imageCount = 0; // Counter for images
                $minImagesBeforeAd = rand(5, 8); // Random number between 5 and 8 for minimum images before showing ad
            ?>

            <?php $__currentLoopData = $galleryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.image_card', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php
                    $imageCount++; // Increment image counter
                ?>

                <!-- Show ad after every 5-8 images -->
                <?php if($imageCount >= $minImagesBeforeAd): ?>
                    <?php if($ads->isNotEmpty()): ?>
                        <!-- Display an ad (you can create a separate partial for the ad) -->
                        <?php
                            $ad = $ads->random();  // Randomly select an ad
                        ?>
                        <?php echo $__env->make('partials.ad_card', ['ad' => $ad], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                    <?php
                        // Reset counter and set a new random number of images before showing the next ad
                        $imageCount = 0;
                        $minImagesBeforeAd = rand(5, 8); // Reset for next interval
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <div class="text-center py-5">
                <h4 class="text-white">No images present in "<strong><?php echo e($category->category_name); ?></strong>"</h4>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php echo $__env->make('vendor.pagination.custom-pagination', ['paginator' => $galleryItems], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/categories/show.blade.php ENDPATH**/ ?>