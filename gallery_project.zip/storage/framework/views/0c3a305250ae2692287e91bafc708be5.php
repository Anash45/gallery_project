

<?php $__env->startSection('title', 'Home - Gallery App'); ?>

<?php $__env->startSection('content'); ?>
    <section class="projects-page">
        <div class="container">
            <div class="section-title text-center mt-5">
                <h2 class="section-title__title">Recently Added</h2>
            </div>
            <div class="row">
                <?php
                    $imageCount = 0; // Counter for images
                    $minImagesBeforeAd = rand(5, 8); // Random number between 5 and 8 for minimum images before showing ad
                    $adCount = 0; // Counter for ads
                ?>

                <?php $__currentLoopData = $recentImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.image_card', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php
                        $imageCount++; // Increment image counter
                    ?>

                    <!-- Show 2 ads after every 5-8 images -->
                    <?php if($imageCount >= $minImagesBeforeAd && $adCount < 2): ?>
                        <?php if($recentAds->isNotEmpty()): ?>
                            <!-- Randomly select and display an ad -->
                            <?php
                                $ad = $recentAds->random();  // Randomly select an ad
                            ?>
                            <?php echo $__env->make('partials.ad_card', ['ad' => $ad], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endif; ?>
                        <?php
                            $adCount++; // Increment ad counter
                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="category-section py-5">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="text-white fw-semibold"><?php echo e($category->category_name); ?></h2>
                    <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="thm-btn login-page__form-btn py-2">Explore More</a>
                </div>
                <div class="row">
                    <?php
                        $imageCount = 0; // Counter for images
                        $minImagesBeforeAd = rand(5, 7); // Random number between 5 and 8 for minimum images before showing ad
                    ?>

                    <?php $__currentLoopData = $category->galleryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.image_card', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php
                            $imageCount++; // Increment image counter
                        ?>

                        <!-- Show ad after every 5-8 images -->
                        <?php if($imageCount >= $minImagesBeforeAd): ?>
                            <?php if($category->ads->isNotEmpty()): ?>
                                <!-- Randomly select and display an ad -->
                                <?php
                                    $ad = $category->ads->random();  // Randomly select an ad for the category
                                ?>
                                <?php echo $__env->make('partials.ad_card', ['ad' => $ad], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                            <?php
                                // Reset counter and set a new random number of images before showing the next ad
                                $imageCount = 0;
                                $minImagesBeforeAd = rand(5, 7); // Reset for next interval
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/home.blade.php ENDPATH**/ ?>