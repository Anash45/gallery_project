<div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6">
    <div class="project-one__single">
        <div class="project-one__img-box">
            <div class="project-one__img">
                <img src="<?php echo e($item->database->base_url); ?>upload/thumbs/<?php echo e($item->image_thumb); ?>" loading="lazy"
                    alt="<?php echo e($item->image_name); ?>" class="w-100">
            </div>
            <div class="project-one__content">
                <div class="project-one__title-box">
                    <h3 class="project-one__title"><a href="/image/<?php echo e($item->slug); ?>"><?php echo e($item->image_name); ?></a></h3>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/image_card.blade.php ENDPATH**/ ?>