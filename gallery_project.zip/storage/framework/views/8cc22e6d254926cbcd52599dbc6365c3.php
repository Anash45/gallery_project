<div class="custom-cursor__cursor"></div>
<div class="custom-cursor__cursor-two"></div><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/cursor.blade.php ENDPATH**/ ?>