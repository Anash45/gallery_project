<div class="preloader">
        <div class="preloader__image"></div>
</div><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/preloader.blade.php ENDPATH**/ ?>