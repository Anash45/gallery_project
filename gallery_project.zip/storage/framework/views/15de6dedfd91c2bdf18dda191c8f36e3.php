<!DOCTYPE html>
<html lang="en">
<head>
    
    <title><?php echo $__env->yieldContent('title', config('app.name', 'Gallery App')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description', 'Default description for the gallery app'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords', 'gallery, images, photos'); ?>">
    
    
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pitoon-dark.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>" />
    
    
    <?php echo $__env->yieldPushContent('styles'); ?>
    
    
    <?php echo $__env->yieldPushContent('inline-css'); ?>
</head>

<body class="custom-cursor">
    
    <?php echo $__env->make('partials.cursor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <?php echo $__env->make('partials.preloader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <div class="page-wrapper">
        
        <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        
        <main>
            
            <?php echo $__env->yieldContent('content'); ?>
            
            
            <?php if (! empty(trim($__env->yieldContent('hero')))): ?>
                <?php echo $__env->yieldContent('hero'); ?>
            <?php endif; ?>
        </main>
        
        
        <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    
    
    <?php echo $__env->make('partials.mobile-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <?php echo $__env->make('partials.search-popup', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <a href="#" data-target="html" class="scroll-to-target scroll-to-top">
        <i class="icon-up-arrow"></i>
    </a>
    
    
    <?php echo $__env->make('partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script src="<?php echo e(asset('assets/js/pitoon.js')); ?>"></script>
    
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    
    <?php echo $__env->yieldPushContent('inline-scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/layouts/app.blade.php ENDPATH**/ ?>