<div class="search-popup">
    <div class="search-popup__overlay search-toggler"></div>
    <!-- ..:: /.search-popup__overlay  ::.. -->
    <div class="search-popup__content">
        <form action="<?php echo e(route('search')); ?>" method="GET">
            <label for="search" class="sr-only">search here</label>
            <input
                type="text"
                id="search"
                name="q"
                value="<?php echo e(request('q')); ?>"
                placeholder="Search Here..."
                required
            />
            <button type="submit" aria-label="search submit" class="thm-btn">
                <i class="icon-magnifying-glass"></i>
            </button>
        </form>
    </div>
    <!-- ..:: /.search-popup__content  ::.. -->
</div>
<?php /**PATH C:\xampp\htdocs\ram_65\gallery_project\resources\views/partials/search-popup.blade.php ENDPATH**/ ?>